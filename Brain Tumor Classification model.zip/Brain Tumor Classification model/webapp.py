import streamlit as st
import numpy as np
import tensorflow as tf
from PIL import Image

# Load model
model = tf.keras.models.load_model("BrainTumor10Epochs_categorical.h5")

# Page title
st.set_page_config(page_title="Brain Tumor Detector", layout="centered")
st.title("Brain Tumor Detection from MRI Scan")
st.write("Upload an MRI scan image and the model will predict whether a brain tumor is present.")

# File uploader
uploaded_file = st.file_uploader("Upload an MRI Image", type=["jpg", "jpeg", "png"])

# Constants
INPUT_SIZE = 64
CLASS_NAMES = ["No Tumor", "Tumor"]

# Prediction
if uploaded_file:
    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption="Uploaded Image", use_column_width=True)

    # Preprocess
    image = image.resize((INPUT_SIZE, INPUT_SIZE))
    img_array = np.array(image) / 255.0
    img_array = img_array.reshape(1, INPUT_SIZE, INPUT_SIZE, 3)

    # Predict
    prediction = model.predict(img_array)
    class_index = np.argmax(prediction)
    confidence = prediction[0][class_index]

    st.markdown("---")
    if class_index == 1:
        st.error(f"Tumor Detected with **{confidence*100:.2f}%** confidence.")
    else:
        st.success(f"No Tumor Detected with **{confidence*100:.2f}%** confidence.")
